


test("Testing function shuffleBoard() for path 1", function() {
	expect(0);
	shuffleBoard();
});


test("Testing function newGame() for path 1", function() {
	expect(0);
	newGame();
});


test("Testing function showCell() for path 1", function() {
	expect(0);
	showCell();
});


test("Testing function showColumnsInGroup() for path 1", function() {
	expect(0);
	showColumnsInGroup();
});


test("Testing function highlightSquare() for path 1", function() {
	expect(0);
	highlightSquare();
});


test("Testing function isGameFinished() for path 1", function() {
	expect(0);
	isGameFinished();
});


test("Testing function initSudoku() for path 1", function() {
	expect(0);
	initSudoku();
});


test("Testing function insertNumber() for path 1", function() {
	expect(0);
	insertNumber();
});


test("Testing function helpMe() for path 1", function() {
	expect(0);
	helpMe();
});


test("Testing function isCorrect() for path 1", function() {
	expect(0);
	isCorrect();
});


test("Testing function getPossibleNumbers() for path 1", function() {
	expect(0);
	getPossibleNumbers();
});


test("Testing function showHint() for path 1", function() {
	expect(0);
	showHint();
});


test("Testing function revealAll() for path 1", function() {
	expect(0);
	revealAll();
});


test("Testing function switchLevel() for path 1", function() {
	expect(0);
	switchLevel();
});

