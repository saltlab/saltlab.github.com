


test("Testing function shuffleBoard() for path 1", function() {
	expect(0);
	shuffleBoard();
});


test("Testing function newGame() for path 1", function() {
	expect(0);
	newGame();
});


test("Testing function showCell(null) for path 1", function() {
	expect(0);
	showCell(null);
});


test("Testing function var inputDiv = document.createElement('div'); document.body.appendChild(inputDiv); showCell(inputDiv) for path 1", function() {
	expect(0);
	var inputDiv = document.createElement('div'); document.body.appendChild(inputDiv); showCell(inputDiv);
});


test("Testing function showColumnsInGroup() for path 1", function() {
	expect(0);
	showColumnsInGroup();
});


test("Testing function var inputObj = document.createElement('div'); inputObj.style.backgroundColor = 'red'; document.body.appendChild(inputObj); highlightSquare(null,inputObj); for path 1", function() {
	expect(0);
	var inputObj = document.createElement('div'); inputObj.style.backgroundColor = 'red'; document.body.appendChild(inputObj); highlightSquare(null,inputObj);;
});


test("Testing function var inputObj = document.createElement('div'); inputObj.style.backgroundColor = 'red'; document.body.appendChild(inputObj); highlightSquare(null,inputObj); for path 1", function() {
	expect(0);
	var inputObj = document.createElement('div'); inputObj.style.backgroundColor = 'red'; document.body.appendChild(inputObj); highlightSquare(null,inputObj);;
});


test("Testing function gameFinished = true; highlightSquare(null,null); for path 1", function() {
	expect(0);
	gameFinished = true; highlightSquare(null,null);;
});


test("Testing function isGameFinished() for path 1", function() {
	expect(0);
	isGameFinished();
});


test("Testing function initSudoku() for path 1", function() {
	expect(0);
	initSudoku();
});


test("Testing function insertNumber() for path 1", function() {
	expect(0);
	insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); gameFinished = true; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); gameFinished = true; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_0'; document.body.appendChild(higlightedCell); code = 37; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_0'; document.body.appendChild(higlightedCell); code = 37; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_8'; document.body.appendChild(higlightedCell); code = 37; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_8'; document.body.appendChild(higlightedCell); code = 37; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_0'; document.body.appendChild(higlightedCell); code = 38; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_0'; document.body.appendChild(higlightedCell); code = 38; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); higlightedCell.id = 'square_8_0'; document.body.appendChild(higlightedCell); code = 38; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); higlightedCell.id = 'square_8_0'; document.body.appendChild(higlightedCell); code = 38; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_0'; document.body.appendChild(higlightedCell); code = 39; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_0'; document.body.appendChild(higlightedCell); code = 39; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_8'; document.body.appendChild(higlightedCell); code = 39; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_8'; document.body.appendChild(higlightedCell); code = 39; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_0'; document.body.appendChild(higlightedCell); code = 40; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); higlightedCell.id = 'square_0_0'; document.body.appendChild(higlightedCell); code = 40; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); higlightedCell.id = 'square_8_0'; document.body.appendChild(higlightedCell); code = 40; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); higlightedCell.id = 'square_8_0'; document.body.appendChild(higlightedCell); code = 40; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 8; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 8; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 46; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 46; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 50; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 50; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 100; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 100; insertNumber();
});


test("Testing function higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 110; insertNumber() for path 1", function() {
	expect(0);
	higlightedCell = document.createElement('div'); document.body.appendChild(higlightedCell); code = 110; insertNumber();
});


test("Testing function helpMe() for path 1", function() {
	expect(0);
	helpMe();
});


test("Testing function isCorrect(null) for path 1", function() {
	expect(0);
	isCorrect(null);
});


test("Testing function getPossibleNumbers(null) for path 1", function() {
	expect(0);
	getPossibleNumbers(null);
});


test("Testing function showHint() for path 1", function() {
	expect(0);
	showHint();
});


test("Testing function revealAll() for path 1", function() {
	expect(0);
	revealAll();
});


test("Testing function switchLevel(1) for path 1", function() {
	expect(0);
	switchLevel(1);
});


test("Testing function gameFinished=true; switchLevel(1) for path 1", function() {
	expect(0);
	gameFinished=true; switchLevel(1);
});

