


test("Testing function createNewTaskElement() for path 1", function() {
	expect(0);
	createNewTaskElement();
});


test("Testing function addTask() for path 1", function() {
	expect(0);
	addTask();
});


test("Testing function editTask() for path 1", function() {
	expect(0);
	editTask();
});


test("Testing function deleteTask() for path 1", function() {
	expect(0);
	deleteTask();
});


test("Testing function tasksCompleted() for path 1", function() {
	expect(0);
	tasksCompleted();
});


test("Testing function tasksIncomplete() for path 1", function() {
	expect(0);
	tasksIncomplete();
});


test("Testing function bindTaskEvents() for path 1", function() {
	expect(0);
	bindTaskEvents();
});

