


test("Testing function SaveRatio() for path 1", function() {
	expect(0);
	SaveRatio();
});


test("Testing function MouseDown('a','a') for path 1", function() {
	expect(0);
	MouseDown('a','a');
});


test("Testing function MouseDownTheSkeleton('a') for path 1", function() {
	expect(0);
	MouseDownTheSkeleton('a');
});


test("Testing function ExpandSkl() for path 1", function() {
	expect(0);
	ExpandSkl();
});


test("Testing function MouseMoveInside('test') for path 1", function() {
	expect(0);
	MouseMoveInside('test');
});


test("Testing function UpdateThumbPrev() for path 1", function() {
	expect(0);
	UpdateThumbPrev();
});

