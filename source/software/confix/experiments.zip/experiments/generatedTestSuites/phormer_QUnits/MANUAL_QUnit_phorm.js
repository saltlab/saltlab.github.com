


test("Testing function dg('id') for path 1", function() {
	expect(0);
	dg('id');
});


test("Testing function toggleInfo() for path 1", function() {
	expect(0);
	toggleInfo();
});


test("Testing function toggleInfo('') for path 1", function() {
	expect(0);
	toggleInfo('');
});


test("Testing function toggleInfo('Show') for path 1", function() {
	expect(0);
	toggleInfo('Show');
});


test("Testing function toggleInfo('Hide') for path 1", function() {
	expect(0);
	toggleInfo('Hide');
});


test("Testing function reToggleInfo() for path 1", function() {
	expect(0);
	reToggleInfo();
});


test("Testing function reshuffle() for path 1", function() {
	expect(0);
	reshuffle();
});


test("Testing function updateIndic() for path 1", function() {
	expect(0);
	updateIndic();
});


test("Testing function SaveRating(0,1) for path 1", function() {
	expect(0);
	SaveRating(0,1);
});


test("Testing function SaveRating(0,0) for path 1", function() {
	expect(0);
	SaveRating(0,0);
});


test("Testing function prepareBody() for path 1", function() {
	expect(0);
	prepareBody();
});


test("Testing function hideElem('id') for path 1", function() {
	expect(0);
	hideElem('id');
});


test("Testing function showElem('id') for path 1", function() {
	expect(0);
	showElem('id');
});


test("Testing function inlineElem('id') for path 1", function() {
	expect(0);
	inlineElem('id');
});


test("Testing function tableRowElem('id') for path 1", function() {
	expect(0);
	tableRowElem('id');
});


test("Testing function checkWV() for path 1", function() {
	expect(0);
	checkWV();
});


test("Testing function doReply(0) for path 1", function() {
	expect(0);
	doReply(0);
});


test("Testing function doReply(1) for path 1", function() {
	expect(0);
	doReply(1);
});


test("Testing function ss_next() for path 1", function() {
	expect(0);
	ss_next();
});


test("Testing function ss_prev() for path 1", function() {
	expect(0);
	ss_prev();
});


test("Testing function ss_update() for path 1", function() {
	expect(0);
	ss_update();
});


test("Testing function ss_playpause() for path 1", function() {
	expect(0);
	ss_playpause();
});


test("Testing function ss_toggleSmaller() for path 1", function() {
	expect(0);
	ss_toggleSmaller();
});


test("Testing function ss_run() for path 1", function() {
	expect(0);
	ss_run();
});


test("Testing function ss_slideshow() for path 1", function() {
	expect(0);
	ss_slideshow();
});

