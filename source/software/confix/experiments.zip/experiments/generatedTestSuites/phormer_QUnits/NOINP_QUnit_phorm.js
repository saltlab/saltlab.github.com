


test("Testing function dg() for path 1", function() {
	expect(0);
	dg();
});


test("Testing function toggleInfo() for path 1", function() {
	expect(0);
	toggleInfo();
});


test("Testing function reToggleInfo() for path 1", function() {
	expect(0);
	reToggleInfo();
});


test("Testing function reshuffle() for path 1", function() {
	expect(0);
	reshuffle();
});


test("Testing function updateIndic() for path 1", function() {
	expect(0);
	updateIndic();
});


test("Testing function SaveRating() for path 1", function() {
	expect(0);
	SaveRating();
});


test("Testing function prepareBody() for path 1", function() {
	expect(0);
	prepareBody();
});


test("Testing function hideElem() for path 1", function() {
	expect(0);
	hideElem();
});


test("Testing function showElem() for path 1", function() {
	expect(0);
	showElem();
});


test("Testing function inlineElem() for path 1", function() {
	expect(0);
	inlineElem();
});


test("Testing function tableRowElem() for path 1", function() {
	expect(0);
	tableRowElem();
});


test("Testing function checkWV() for path 1", function() {
	expect(0);
	checkWV();
});


test("Testing function doReply() for path 1", function() {
	expect(0);
	doReply();
});


test("Testing function ss_next() for path 1", function() {
	expect(0);
	ss_next();
});


test("Testing function ss_prev() for path 1", function() {
	expect(0);
	ss_prev();
});


test("Testing function ss_update() for path 1", function() {
	expect(0);
	ss_update();
});


test("Testing function ss_playpause() for path 1", function() {
	expect(0);
	ss_playpause();
});


test("Testing function ss_toggleSmaller() for path 1", function() {
	expect(0);
	ss_toggleSmaller();
});


test("Testing function ss_run() for path 1", function() {
	expect(0);
	ss_run();
});


test("Testing function ss_slideshow() for path 1", function() {
	expect(0);
	ss_slideshow();
});

