


test("Testing function PrepareBody() for path 1", function() {
	expect(0);
	PrepareBody();
});


test("Testing function dg('test') for path 1", function() {
	expect(0);
	dg('test');
});


test("Testing function hideElem('test') for path 1", function() {
	expect(0);
	hideElem('test');
});


test("Testing function showElem('test') for path 1", function() {
	expect(0);
	showElem('test');
});


test("Testing function inlineElem('test') for path 1", function() {
	expect(0);
	inlineElem('test');
});


test("Testing function tableRowElem('test') for path 1", function() {
	expect(0);
	tableRowElem('test');
});


test("Testing function checkChangePass() for path 1", function() {
	expect(0);
	checkChangePass();
});


test("Testing function checkInstallPass() for path 1", function() {
	expect(0);
	checkInstallPass();
});


test("Testing function checkPrivacyRow() for path 1", function() {
	expect(0);
	checkPrivacyRow();
});


test("Testing function checkHasPass() for path 1", function() {
	expect(0);
	checkHasPass();
});


test("Testing function checkDate() for path 1", function() {
	expect(0);
	checkDate();
});


test("Testing function CheckAddPhotoTime() for path 1", function() {
	expect(0);
	CheckAddPhotoTime();
});


test("Testing function CheckAddPhoto() for path 1", function() {
	expect(0);
	CheckAddPhoto();
});


test("Testing function confirmDelete('test') for path 1", function() {
	expect(0);
	confirmDelete('test');
});


test("Testing function ConfirmDelPhotoID('test') for path 1", function() {
	expect(0);
	ConfirmDelPhotoID('test');
});


test("Testing function ConfirmDelPhoto() for path 1", function() {
	expect(0);
	ConfirmDelPhoto();
});


test("Testing function ConfirmRestore() for path 1", function() {
	expect(0);
	ConfirmRestore();
});


test("Testing function ConfirmSave() for path 1", function() {
	expect(0);
	ConfirmSave();
});


test("Testing function showlinkline('test') for path 1", function() {
	expect(0);
	showlinkline('test');
});


test("Testing function hidelinkline('test') for path 1", function() {
	expect(0);
	hidelinkline('test');
});


test("Testing function linkAddBelow(0) for path 1", function() {
	expect(0);
	linkAddBelow(0);
});


test("Testing function linkDelThis() for path 1", function() {
	expect(0);
	linkDelThis();
});


test("Testing function removeThisNode('test') for path 1", function() {
	expect(0);
	removeThisNode('test');
});


test("Testing function addMainColDiv() for path 1", function() {
	expect(0);
	addMainColDiv();
});


test("Testing function updateMode() for path 1", function() {
	expect(0);
	updateMode();
});


test("Testing function fixBoldInput('test','test1') for path 1", function() {
	expect(0);
	fixBoldInput('test','test1');
});


test("Testing function changePrev() for path 1", function() {
	expect(0);
	changePrev();
});


test("Testing function ToggleAdvPref() for path 1", function() {
	expect(0);
	ToggleAdvPref();
});


test("Testing function updateTimeDiffer('test') for path 1", function() {
	expect(0);
	updateTimeDiffer('test');
});


test("Testing function CheckDateDrafts() for path 1", function() {
	expect(0);
	CheckDateDrafts();
});


test("Testing function CheckActionDrafts() for path 1", function() {
	expect(0);
	CheckActionDrafts();
});


test("Testing function CheckDeleteThisDrafts('test') for path 1", function() {
	expect(0);
	CheckDeleteThisDrafts('test');
});


test("Testing function updateSelCount() for path 1", function() {
	expect(0);
	updateSelCount();
});


test("Testing function DraftsSelectBit('test','test1') for path 1", function() {
	expect(0);
	DraftsSelectBit('test','test1');
});


test("Testing function AddAddBox() for path 1", function() {
	expect(0);
	AddAddBox();
});

