


test("Testing function HideHelp() for path 1", function() {
	expect(0);
	HideHelp();
});


test("Testing function dgp() for path 1", function() {
	expect(0);
	dgp();
});


test("Testing function ShowHelp() for path 1", function() {
	expect(0);
	ShowHelp();
});


test("Testing function SwitchSelectIE() for path 1", function() {
	expect(0);
	SwitchSelectIE();
});


test("Testing function GetItHelpMsg() for path 1", function() {
	expect(0);
	GetItHelpMsg();
});

