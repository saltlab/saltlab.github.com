


test("Testing function setExif('test') for path 1", function() {
	expect(0);
	setExif('test');
});


test("Testing function AjaxVal[0] = '!test'; setExif('test') for path 1", function() {
	expect(0);
	AjaxVal[0] = '!test'; setExif('test');
});


test("Testing function AjaxVal[0] = 'test;'; setExif('test') for path 1", function() {
	expect(0);
	AjaxVal[0] = 'test;'; setExif('test');
});


test("Testing function AjaxVal[0] = null; setExif('test') for path 1", function() {
	expect(0);
	AjaxVal[0] = null; setExif('test');
});


test("Testing function imageUploaded(false, 'test') for path 1", function() {
	expect(0);
	imageUploaded(false, 'test');
});


test("Testing function imageUploaded(true, 'test') for path 1", function() {
	expect(0);
	imageUploaded(true, 'test');
});


test("Testing function hasgd = false; imageUploaded(true, 'test') for path 1", function() {
	expect(0);
	hasgd = false; imageUploaded(true, 'test');
});


test("Testing function AjaxVal[0] = ''; writeYet('test', false) for path 1", function() {
	expect(0);
	AjaxVal[0] = ''; writeYet('test', false);
});


test("Testing function AjaxVal[0] = ''; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = ''; writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'ERRORtest'; writeYet('test', false) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'ERRORtest'; writeYet('test', false);
});


test("Testing function AjaxVal[0] = 'ERRORtest'; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'ERRORtest'; writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'DELEDtest'; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'DELEDtest'; writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'DELEDtest'; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'DELEDtest'; writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'EMPTYtest'; writeYet('test', false) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'EMPTYtest'; writeYet('test', false);
});


test("Testing function AjaxVal[0] = 'EMPTYtest'; pcupload = true; writeYet('test', false) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'EMPTYtest'; pcupload = true; writeYet('test', false);
});


test("Testing function AjaxVal[0] = 'EMPTYtest'; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'EMPTYtest'; writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'EMPTYtest'; pcupload = true; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'EMPTYtest'; pcupload = true; writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'STARTtest'; writeYet('test', false) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'STARTtest'; writeYet('test', false);
});


test("Testing function AjaxVal[0] = 'STARTtest'; pcupload = true;  writeYet('test', false) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'STARTtest'; pcupload = true;  writeYet('test', false);
});


test("Testing function AjaxVal[0] = 'STARTtest'; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'STARTtest'; writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'STARTtest'; pcupload = true;  writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'STARTtest'; pcupload = true;  writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'THUMBtest'; writeYet('test', false) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'THUMBtest'; writeYet('test', false);
});


test("Testing function AjaxVal[0] = 'THUMBtest'; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'THUMBtest'; writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'UNZIPtest'; writeYet('test', false) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'UNZIPtest'; writeYet('test', false);
});


test("Testing function AjaxVal[0] = 'UNZIPtest'; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'UNZIPtest'; writeYet('test', true);
});


test("Testing function AjaxVal[0] = 'ENDEDtest'; writeYet('test', false) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'ENDEDtest'; writeYet('test', false);
});


test("Testing function AjaxVal[0] = 'ENDEDtest'; writeYet('test', true) for path 1", function() {
	expect(0);
	AjaxVal[0] = 'ENDEDtest'; writeYet('test', true);
});


test("Testing function uploadSubmitted('test', 'test', false, 'test')  for path 1", function() {
	expect(0);
	uploadSubmitted('test', 'test', false, 'test') ;
});


test("Testing function uploadSubmitted('test', 'test', true, 'test')  for path 1", function() {
	expect(0);
	uploadSubmitted('test', 'test', true, 'test') ;
});


test("Testing function rethumb_fill('test') for path 1", function() {
	expect(0);
	rethumb_fill('test');
});


test("Testing function rethumb() for path 1", function() {
	expect(0);
	rethumb();
});

