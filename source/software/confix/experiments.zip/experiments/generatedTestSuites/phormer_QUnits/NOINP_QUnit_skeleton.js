


test("Testing function SaveRatio() for path 1", function() {
	expect(0);
	SaveRatio();
});


test("Testing function MouseDown() for path 1", function() {
	expect(0);
	MouseDown();
});


test("Testing function MouseDownTheSkeleton() for path 1", function() {
	expect(0);
	MouseDownTheSkeleton();
});


test("Testing function ExpandSkl() for path 1", function() {
	expect(0);
	ExpandSkl();
});


test("Testing function MouseMoveInside() for path 1", function() {
	expect(0);
	MouseMoveInside();
});


test("Testing function UpdateThumbPrev() for path 1", function() {
	expect(0);
	UpdateThumbPrev();
});

