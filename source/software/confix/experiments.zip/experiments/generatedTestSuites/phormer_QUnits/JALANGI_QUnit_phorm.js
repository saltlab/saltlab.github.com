


test("Testing function dg('test') for path 1", function() {
	expect(0);
	dg('test');
});


test("Testing function toggleInfo('Show') for path 1", function() {
	expect(0);
	toggleInfo('Show');
});


test("Testing function toggleInfo('a') for path 1", function() {
	expect(0);
	toggleInfo('a');
});


test("Testing function reToggleInfo() for path 1", function() {
	expect(0);
	reToggleInfo();
});


test("Testing function reshuffle() for path 1", function() {
	expect(0);
	reshuffle();
});


test("Testing function updateIndic() for path 1", function() {
	expect(0);
	updateIndic();
});


test("Testing function SaveRating('','') for path 1", function() {
	expect(0);
	SaveRating('','');
});


test("Testing function prepareBody() for path 1", function() {
	expect(0);
	prepareBody();
});


test("Testing function hideElem('test') for path 1", function() {
	expect(0);
	hideElem('test');
});


test("Testing function showElem('test') for path 1", function() {
	expect(0);
	showElem('test');
});


test("Testing function inlineElem('test') for path 1", function() {
	expect(0);
	inlineElem('test');
});


test("Testing function tableRowElem('test') for path 1", function() {
	expect(0);
	tableRowElem('test');
});


test("Testing function checkWV() for path 1", function() {
	expect(0);
	checkWV();
});


test("Testing function doReply('test') for path 1", function() {
	expect(0);
	doReply('test');
});


test("Testing function ss_next() for path 1", function() {
	expect(0);
	ss_next();
});


test("Testing function ss_prev() for path 1", function() {
	expect(0);
	ss_prev();
});


test("Testing function ss_update() for path 1", function() {
	expect(0);
	ss_update();
});


test("Testing function ss_playpause() for path 1", function() {
	expect(0);
	ss_playpause();
});


test("Testing function ss_toggleSmaller() for path 1", function() {
	expect(0);
	ss_toggleSmaller();
});


test("Testing function ss_run() for path 1", function() {
	expect(0);
	ss_run();
});


test("Testing function ss_slideshow() for path 1", function() {
	expect(0);
	ss_slideshow();
});

