


test("Testing function HideHelp() for path 1", function() {
	expect(0);
	$("#qunit-fixture").append(' <div id="helpBox" value="" style="display:initial"/> ');
	HideHelp();
});


test("Testing function dgp() for path 1", function() {
	expect(0);
	$("#qunit-fixture").append(' <div id="null" value="" style="display:initial"/> ');
	dgp();
});


test("Testing function ShowHelp() for path 1", function() {
	expect(0);
	$("#qunit-fixture").append(' <div id="helpBoxLegend" value="" style="display:initial"/> ');
	ShowHelp();
});


test("Testing function SwitchSelectIE() for path 1", function() {
	expect(0);
	SwitchSelectIE();
});


test("Testing function GetItHelpMsg() for path 1", function() {
	expect(0);
	GetItHelpMsg();
});

