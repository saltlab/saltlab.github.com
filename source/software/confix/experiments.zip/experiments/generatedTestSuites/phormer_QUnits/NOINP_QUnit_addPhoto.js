


test("Testing function setExif() for path 1", function() {
	expect(0);
	setExif();
});


test("Testing function imageUploaded() for path 1", function() {
	expect(0);
	imageUploaded();
});


test("Testing function writeYet() for path 1", function() {
	expect(0);
	writeYet();
});


test("Testing function uploadSubmitted()  for path 1", function() {
	expect(0);
	uploadSubmitted() ;
});


test("Testing function rethumb_fill() for path 1", function() {
	expect(0);
	rethumb_fill();
});


test("Testing function rethumb() for path 1", function() {
	expect(0);
	rethumb();
});

