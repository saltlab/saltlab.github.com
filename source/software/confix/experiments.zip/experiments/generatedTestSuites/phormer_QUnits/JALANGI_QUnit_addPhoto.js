


test("Testing function setExif('test') for path 1", function() {
	expect(0);
	setExif('test');
});


test("Testing function imageUploaded('test', 'test') for path 1", function() {
	expect(0);
	imageUploaded('test', 'test');
});


test("Testing function writeYet('test', 'test') for path 1", function() {
	expect(0);
	writeYet('test', 'test');
});


test("Testing function uploadSubmitted('a', 'a', 'a', '')  for path 1", function() {
	expect(0);
	uploadSubmitted('a', 'a', 'a', '') ;
});


test("Testing function rethumb_fill('test') for path 1", function() {
	expect(0);
	rethumb_fill('test');
});


test("Testing function rethumb() for path 1", function() {
	expect(0);
	rethumb();
});

