


test("Testing function PrepareBody() for path 1", function() {
	expect(0);
	PrepareBody();
});


test("Testing function dg() for path 1", function() {
	expect(0);
	dg();
});


test("Testing function hideElem() for path 1", function() {
	expect(0);
	hideElem();
});


test("Testing function showElem() for path 1", function() {
	expect(0);
	showElem();
});


test("Testing function inlineElem() for path 1", function() {
	expect(0);
	inlineElem();
});


test("Testing function tableRowElem() for path 1", function() {
	expect(0);
	tableRowElem();
});


test("Testing function checkChangePass() for path 1", function() {
	expect(0);
	checkChangePass();
});


test("Testing function checkInstallPass() for path 1", function() {
	expect(0);
	checkInstallPass();
});


test("Testing function checkPrivacyRow() for path 1", function() {
	expect(0);
	checkPrivacyRow();
});


test("Testing function checkHasPass() for path 1", function() {
	expect(0);
	checkHasPass();
});


test("Testing function checkDate() for path 1", function() {
	expect(0);
	checkDate();
});


test("Testing function CheckAddPhotoTime() for path 1", function() {
	expect(0);
	CheckAddPhotoTime();
});


test("Testing function CheckAddPhoto() for path 1", function() {
	expect(0);
	CheckAddPhoto();
});


test("Testing function confirmDelete() for path 1", function() {
	expect(0);
	confirmDelete();
});


test("Testing function ConfirmDelPhotoID() for path 1", function() {
	expect(0);
	ConfirmDelPhotoID();
});


test("Testing function ConfirmDelPhoto() for path 1", function() {
	expect(0);
	ConfirmDelPhoto();
});


test("Testing function ConfirmRestore() for path 1", function() {
	expect(0);
	ConfirmRestore();
});


test("Testing function ConfirmSave() for path 1", function() {
	expect(0);
	ConfirmSave();
});


test("Testing function showlinkline() for path 1", function() {
	expect(0);
	showlinkline();
});


test("Testing function hidelinkline() for path 1", function() {
	expect(0);
	hidelinkline();
});


test("Testing function linkAddBelow() for path 1", function() {
	expect(0);
	linkAddBelow();
});


test("Testing function linkDelThis() for path 1", function() {
	expect(0);
	linkDelThis();
});


test("Testing function removeThisNode() for path 1", function() {
	expect(0);
	removeThisNode();
});


test("Testing function addMainColDiv() for path 1", function() {
	expect(0);
	addMainColDiv();
});


test("Testing function updateMode() for path 1", function() {
	expect(0);
	updateMode();
});


test("Testing function fixBoldInput() for path 1", function() {
	expect(0);
	fixBoldInput();
});


test("Testing function changePrev() for path 1", function() {
	expect(0);
	changePrev();
});


test("Testing function ToggleAdvPref() for path 1", function() {
	expect(0);
	ToggleAdvPref();
});


test("Testing function updateTimeDiffer() for path 1", function() {
	expect(0);
	updateTimeDiffer();
});


test("Testing function CheckDateDrafts() for path 1", function() {
	expect(0);
	CheckDateDrafts();
});


test("Testing function CheckActionDrafts() for path 1", function() {
	expect(0);
	CheckActionDrafts();
});


test("Testing function updateSelCount() for path 1", function() {
	expect(0);
	updateSelCount();
});


test("Testing function DraftsSelectBit() for path 1", function() {
	expect(0);
	DraftsSelectBit();
});


test("Testing function CheckDeleteThisDrafts() for path 1", function() {
	expect(0);
	CheckDeleteThisDrafts();
});


test("Testing function AddAddBox() for path 1", function() {
	expect(0);
	AddAddBox();
});

