


test("Testing function checkPassConfirm() for path 1", function() {
	expect(0);
	checkPassConfirm();
});


test("Testing function checkValid() for path 1", function() {
	expect(0);
	checkValid();
});


test("Testing function RequiredField(null) for path 1", function() {
	expect(0);
	RequiredField(null);
});


test("Testing function validateEmail() for path 1", function() {
	expect(0);
	validateEmail();
});


test("Testing function validateNumber(null) for path 1", function() {
	expect(0);
	validateNumber(null);
});


test("Testing function var f = document.createElement('form'); f.name = 'frm'; document.body.appendChild(f);var phone = document.createElement('input'); phone.name = 'phnum';  f.appendChild(phone); validateNumber(f) for path 1", function() {
	expect(0);
	var f = document.createElement('form'); f.name = 'frm'; document.body.appendChild(f);var phone = document.createElement('input'); phone.name = 'phnum';  f.appendChild(phone); validateNumber(f);
});


test("Testing function RequiredField(null) for path 1", function() {
	expect(0);
	RequiredField(null);
});


test("Testing function var f = document.createElement('form'); f.name = 'frm'; document.body.appendChild(f);var phone = document.createElement('input'); phone.name = 'phnum';  f.appendChild(phone); RequiredField(f) for path 1", function() {
	expect(0);
	var f = document.createElement('form'); f.name = 'frm'; document.body.appendChild(f);var phone = document.createElement('input'); phone.name = 'phnum';  f.appendChild(phone); RequiredField(f);
});

