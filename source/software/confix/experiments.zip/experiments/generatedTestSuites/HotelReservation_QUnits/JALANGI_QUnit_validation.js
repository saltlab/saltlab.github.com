


test("Testing function checkPassConfirm() for path 1", function() {
	expect(0);
	checkPassConfirm();
});


test("Testing function checkValid() for path 1", function() {
	expect(0);
	checkValid();
});


test("Testing function RequiredField() for path 1", function() {
	expect(0);
	RequiredField();
});


test("Testing function validateEmail() for path 1", function() {
	expect(0);
	validateEmail();
});


test("Testing function validateNumber() for path 1", function() {
	expect(0);
	validateNumber();
});

